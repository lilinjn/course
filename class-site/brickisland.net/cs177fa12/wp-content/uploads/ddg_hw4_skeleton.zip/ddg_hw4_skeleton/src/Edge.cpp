#include "Edge.h"
#include "Mesh.h"

namespace DDG
{
   double Edge :: length( void ) const
   // returns the edge length
   {
      // TODO 

      return 0; // <---- not correct!
   }
}

