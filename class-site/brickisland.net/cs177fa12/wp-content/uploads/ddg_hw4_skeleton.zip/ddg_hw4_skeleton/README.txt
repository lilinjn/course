For documentation, see doc/libddg_userguide.pdf
